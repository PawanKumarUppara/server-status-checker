package com.twitter.serverstatuschecker;

import com.twitter.serverstatuschecker.helper.Utility;
import com.twitter.serverstatuschecker.service.StatusCheckerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerStatusCheckerApplication  implements CommandLineRunner {

	@Autowired
	public StatusCheckerService statusCheckerService;
	public static void main(String[] args) {
		SpringApplication.run(ServerStatusCheckerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		statusCheckerService.aggregateByNameAndVersion();
	}
}
