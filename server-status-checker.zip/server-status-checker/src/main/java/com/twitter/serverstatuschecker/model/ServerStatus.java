package com.twitter.serverstatuschecker.model;

public class ServerStatus {
    private String application;
    private String version;
    private Long uptime;
    private Long requestCount;
    private Long errorCount;
    private Long successCount;

    public ServerStatus(String application, String version, Long uptime, Long requestCount, Long errorCount, Long successCount) {
        this.application = application;
        this.version = version;
        this.uptime = uptime;
        this.requestCount = requestCount;
        this.errorCount = errorCount;
        this.successCount = successCount;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Long getUptime() {
        return uptime;
    }

    public void setUptime(Long uptime) {
        this.uptime = uptime;
    }

    public Long getRequestCount() {
        return requestCount;
    }

    public void setRequestCount(Long requestCount) {
        this.requestCount = requestCount;
    }

    public Long getErrorCount() {
        return errorCount;
    }

    public void setErrorCount(Long errorCount) {
        this.errorCount = errorCount;
    }

    public Long getSuccessCount() {
        return successCount;
    }

    public void setSuccessCount(Long successCount) {
        this.successCount = successCount;
    }

    @Override
    public String toString() {
        return "ServerStatus{" +
                "application='" + application + '\'' +
                ", version='" + version + '\'' +
                ", uptime=" + uptime +
                ", requestCount=" + requestCount +
                ", errorCount=" + errorCount +
                ", successCount=" + successCount +
                '}';
    }
}
