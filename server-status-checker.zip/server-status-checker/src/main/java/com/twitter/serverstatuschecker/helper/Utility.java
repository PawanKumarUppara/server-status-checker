package com.twitter.serverstatuschecker.helper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.twitter.serverstatuschecker.model.ServerStatus;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


import java.io.*;
import java.math.BigDecimal;
import java.net.URL;
import java.nio.file.Paths;
import java.util.*;

public class Utility {

	static File file = new File("src/main/resources/files");
	static String absolutePath = file.getAbsolutePath();

    public static final String SERVER_FILE_PATH = absolutePath+"/servers.txt";
    public static final String RESPONSE_FILE_PATH = absolutePath+"/responses.txt";

    public static List<String> readServerData() throws IOException {
        BufferedReader bufReader = new BufferedReader(new FileReader(SERVER_FILE_PATH));
        ArrayList<String> serverNames = new ArrayList<>();
        String line = bufReader.readLine();
        while (line != null) {
            serverNames.add(line);
            line = bufReader.readLine();
        }
        bufReader.close();
        return serverNames;
    }

    public static List<ServerStatus> getServerStasus()
    {
        JSONParser parser = new JSONParser();
        List<ServerStatus> statuses = new ArrayList<>();
        try
        {
            Object object = parser
                    .parse(new FileReader(RESPONSE_FILE_PATH));

            JSONArray jsonArray = (JSONArray) object;
            for(int i=0;i<jsonArray.size();i++){
             JSONObject jsonObject1 = (JSONObject) jsonArray.get(i);
             ServerStatus serverStatus = generateServerStasus(jsonObject1);
             statuses.add(serverStatus);
           }
         return statuses;
        }
        catch(FileNotFoundException fe)
        {
            fe.printStackTrace();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return statuses;
    }

    private static ServerStatus generateServerStasus(JSONObject jsonObject1) {
        String name = (String) jsonObject1.get("Application");
        String version =  (String)jsonObject1.get("Version");
        Long uptime = (Long) jsonObject1.get("Uptime");
        Long requestCount =  (Long)jsonObject1.get("Request_Count");
        Long errorCount = (Long) jsonObject1.get("Error_Count");
        Long successCount =  (Long)jsonObject1.get("Success_Count");
        ServerStatus serverStatus = new ServerStatus(name,version,uptime,requestCount,errorCount,successCount);
        return serverStatus;
    }

    public static Map<String, ServerStatus> mapServersToResponses() throws IOException {
        List<String> serverNames = readServerData();
        List<ServerStatus> serverStatuses = getServerStasus();
        Map<String, ServerStatus> serverMap= new HashMap<>();

        for(int i=0;i<serverNames.size();i++){
            serverMap.put(serverNames.get(i), serverStatuses.get(i));
        }
        return serverMap;
    }

    public static void writeToFile(String json) throws IOException {
        FileOutputStream outputStream = new FileOutputStream("output.txt");
        byte[] strToBytes = json.getBytes();
        outputStream.write(strToBytes);
        outputStream.close();
    }

    public static void printHumanReadable(Map<String, Map<String, BigDecimal>> result) {

        System.out.println("Application Name  ||  Version  ||  Success Rate(%)");
        for (Map.Entry<String, Map<String, BigDecimal>> entry : result.entrySet()){
            String applicationName = entry.getKey();
            Map<String, BigDecimal> versionMap = entry.getValue();
            for(Map.Entry<String, BigDecimal> versionEntry : versionMap.entrySet()){
                String version = versionEntry.getKey();
                BigDecimal successRate = versionEntry.getValue();
                System.out.println(applicationName+"  ||  "+version+"  ||  "+successRate+" %");
            }
        }

    }

    public static String convertToJson(Map<String, Map<String, BigDecimal>> result) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(result);
        return json;
    }
}

