package com.twitter.serverstatuschecker.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.twitter.serverstatuschecker.helper.Utility;
import com.twitter.serverstatuschecker.model.ServerStatus;
//import org.graalvm.compiler.core.common.util.Util;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.groupingBy;

@Service
public class StatusCheckerService {

    public void aggregateByNameAndVersion() throws IOException {
        Map<String, ServerStatus> serverMap = Utility.mapServersToResponses();
        Map<String, Map<String, List<ServerStatus>>> groupedMap = serverMap.values().stream().collect(groupingBy(ServerStatus::getApplication, groupingBy(ServerStatus::getVersion)));
        Map<String, Map<String, BigDecimal>> result = createSuccessRate(groupedMap);
        Utility.printHumanReadable(result);
        String json = Utility.convertToJson(result);
        Utility.writeToFile(json);
    }


    private Map<String, Map<String, BigDecimal>> createSuccessRate(Map<String, Map<String, List<ServerStatus>>> groupedMap) {
        Map<String, Map<String, BigDecimal>> resultSet = new HashMap<>();
        for (Map.Entry<String, Map<String, List<ServerStatus>>> entry : groupedMap.entrySet()){
            String applicationName = entry.getKey();
            Map<String, List<ServerStatus>> versionMap = entry.getValue();
            for(Map.Entry<String, List<ServerStatus>> versionEntry : versionMap.entrySet()){
                String version = versionEntry.getKey();
                List<ServerStatus> serverStatuses = versionEntry.getValue();
                BigDecimal successRate = calculateSuccessRate(serverStatuses);
                Map<String, BigDecimal> successResult = new HashMap<>();
                successResult.put(version, successRate);
                resultSet.put(applicationName, successResult);
            }
        }
        return resultSet;
    }

    private BigDecimal calculateSuccessRate(List<ServerStatus> serverStatuses) {
        final BigDecimal[] successCount = {BigDecimal.ZERO};
        final BigDecimal[] requestCount = {BigDecimal.ZERO};
       serverStatuses.forEach(serverStatus -> {
           successCount[0] = successCount[0].add(BigDecimal.valueOf(serverStatus.getSuccessCount()));
           requestCount[0] = requestCount[0].add(BigDecimal.valueOf(serverStatus.getRequestCount()));

       });
        BigDecimal successRate = successCount[0].divide(requestCount[0],2,RoundingMode.HALF_EVEN).multiply(BigDecimal.valueOf(100));
        return successRate;
    }

}

