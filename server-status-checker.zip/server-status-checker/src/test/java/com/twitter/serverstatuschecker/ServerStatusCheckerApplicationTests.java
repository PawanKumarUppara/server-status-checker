package com.twitter.serverstatuschecker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerStatusCheckerApplicationTests {

	@Test
	void contextLoads() {
	}

}
