## Instructions to Execute the appllication

##Option 1
1.Import the applicaiton to intellij or eclipse.
2.Run the application

it will give below response about the server success rate in this format

output:

Application Name || Version || Success Rate(%)
Cache0 || 1.1.1 || 49.00 %
Cache1 || 1.2.0 || 43.00 %
Webapp0 || 1.2.0 || 56.00 %
Cache2 || 1.1.1 || 42.00 %
Database2 || 1.1.1 || 48.00 %
Database1 || 1.2.0 || 45.00 %
Database0 || 1.0.2 || 56.00 %
Webapp1 || 1.2.0 || 62.00 %
Webapp2 || 1.0.2 || 42.00 %

##Option 2
1.Import the applicaiton to intellij or eclipse.
2.If you have java and maven installed try to build aplication.
3.Now run the applicaiton jar which is in target folder using below command

java -jar server-status-checker-0.0.1-SNAPSHOT.jar

it will give below response about the server success rate in this format

output:

Application Name || Version || Success Rate(%)
Cache0 || 1.1.1 || 49.00 %
Cache1 || 1.2.0 || 43.00 %
Webapp0 || 1.2.0 || 56.00 %
Cache2 || 1.1.1 || 42.00 %
Database2 || 1.1.1 || 48.00 %
Database1 || 1.2.0 || 45.00 %
Database0 || 1.0.2 || 56.00 %
Webapp1 || 1.2.0 || 62.00 %
Webapp2 || 1.0.2 || 42.00 %
